package banco;
import java.util.ArrayList;
import mini.Itinerario;
import mini.Veiculo;
import mini.Passagem;

public class Banco {
	
	public static final ArrayList<Itinerario> itinerario = new ArrayList<Itinerario>();
	public static final ArrayList<Veiculo> veiculo = new ArrayList<Veiculo>();
	public static final ArrayList<Passagem> passagem = new ArrayList<Passagem>();
	
	public static ArrayList<Itinerario> getItinerario(){
		return itinerario;
	}
	
	public static ArrayList<Veiculo> getVeiculo(){
		return veiculo;
	}
	
	public static ArrayList<Passagem> getPassagem(){
		return passagem;
	}
}
