package teste;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import banco.Banco;
import mini.Itinerario;
/**
*Class TesteId que testa se checaId está funcionando
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class TesteID {
	//Método que confirma que a checagem de id está correta
	void checarId() {
		Itinerario itinerarioTeste = new Itinerario();
		String id = "111111";
		itinerarioTeste.setId(id);
		Banco.getItinerario().add(itinerarioTeste);
		
		String idCorreto = "111110";
		String idErrado = "111111";
		assertTrue(Itinerario.checaId(idCorreto));
		assertFalse(Itinerario.checaId(idErrado));
		
	}
}
