package teste;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import mini.Itinerario;
/**
*Class TesteHorario que testa se o metodo checaHorario está correto
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class TesteHorario {
	//Método que confirma que a checagem de horario está correta
	void checarHorario() {
		String horarioCorreta = "11:11";
		String horarioErrada = "24:61";
		assertTrue(Itinerario.checaHorario(horarioCorreta));
		assertFalse(Itinerario.checaHorario(horarioErrada));
	}
}
