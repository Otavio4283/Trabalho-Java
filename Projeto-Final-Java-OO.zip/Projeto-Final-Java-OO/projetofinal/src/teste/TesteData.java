package teste;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


import mini.Itinerario;
/**
*Class TesteData que testa se o metodo checaData está correto
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class TesteData {
	
	 //Método que confirma que a checagem data está correta
	 
	void checarData() {
		String dataCorreta = "11/10/2000";
		String dataErrada = "32/20/2020";
		assertTrue(Itinerario.checaData(dataCorreta));
		assertFalse(Itinerario.checaData(dataErrada));
	}
}
