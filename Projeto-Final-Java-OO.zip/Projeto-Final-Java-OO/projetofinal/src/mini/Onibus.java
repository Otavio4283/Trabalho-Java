package mini;
/**
*Class Onibus que herda variaveis da class Veiculo
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class Onibus extends Veiculo{
	private int portas;
	private int rodas;
	public Onibus() {
		
	}	
	/*
	 	*Gets e sets da variaveis de Onibus 
	 */
	public int getPortas() {
		return portas;
	}
	public void setPortas(int portas) {
		this.portas=portas;
	}
	
	
	
	public int getRodas() {
		return rodas;
	}
	public void setRodas(int rodas) {
		this.rodas=rodas;
	}
}


