package mini;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import banco.Banco;
/**
	*Class Itinerario registra os dados de um itinerario
	*@author Otávio Henrique Moraes Brito
	*@since 2023
	*@version 1.1
**/
public class Itinerario {
	private String id;
	private String origem;
	private String destino;
	private String datasaida;
	private String datachegada;
	private String horariosaida;
	private String horariochegada;

	
	public Itinerario(){
		
	}
	/**
	 	* Gets e sets dos dados da classe
	 */
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id=id;
	}
	
	
	public String getOrigem() {
		return origem;
	}
	public void setOrigem(String origem) {
		this.origem=origem;
	}

	
	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino=destino;
	}

	public String getDatasaida() {
		return datasaida;
	}
	public void setDatasaida(String datasaida) {
		this.datasaida=datasaida;
	}
	 
	
	
	public String getDatachegada() {
		return datachegada;
	}
	public void setDatachegada(String datachegada) {
		this.datachegada=datachegada;
	}
	
	
	
	public String getHorariosaida() {
		return horariosaida;
	}
	public void setHorariosaida(String horariosaida) {
		this.horariosaida=horariosaida;
	}
	
	
	
	public String getHorariochegada() {
		return horariochegada;
	}
	public void setHorariochegada(String horariochegada) {
		this.horariochegada=horariochegada;
	}
	/*
		*Checa se o id inserido já existe retornando falso se for errado
		*@return boolean
	*/
	public static boolean checaId(String id) {
		ArrayList<Itinerario> itinerarios = Banco.getItinerario();
		int i=0;   
		for (Itinerario itinerario : itinerarios) {
	            if (id.equals(itinerario.getId())) {
	                i=1;
	            }
	     }
		 if(i==1) {
			 return false;
		 }else {
			 return true;
		 }
		
	}
	/*
		*Checa se uma data é correta 
		*@return boolean
	*/
	public static boolean checaData(String data) {
		String[] partes = data.split("/");
		int dia, mes, ano;
		boolean bissexto;
		if (partes.length != 3) {
			return false;
		}
		
		
		dia = Integer.parseInt(partes[0]);
		mes = Integer.parseInt(partes[1]);
		ano = Integer.parseInt(partes[2]);
	
		if(ano % 4 == 0 && (ano % 100 != 0 || ano % 400 == 0)) {
			bissexto=true;
		}else {
			bissexto=false;
		}
		if(bissexto==true){
			if(mes==2 && dia<=29) {
				return true;
			}else if(mes!=2 && dia<=29) {
				return false;
			}
		}
		
		if(mes==2 && dia<=28){
			return true;
		}else if((mes==4 || mes==6 || mes==9 || mes==11)&& dia<=30) {
			return true;
		}else if((mes==1 || mes==3 || mes==5 || mes==7 || mes==8 || mes==10 || mes==12)&& dia<=31){
			return true;
		}else {
				return false;
		}
		
		
	}
	/*
		*Checa se um horario inserido é correto
		*@return boolean
	*/
	public static boolean checaHorario(String horario) {
		String[] partes = horario.split(":");
		int horas = Integer.parseInt(partes[0]);
		int minutos = Integer.parseInt(partes[1]);
		
		if(horas<=23 && minutos<=59){
			return true;
		}else {
			return false;
		}
	
	}
	//Metodo sobrescrito toString que foi usada para teste do setId. 
	public String toString(){
		//return getClass().getName() + "@" 
        // + Integer.toHexString(hashCode()); 
		Itinerario itin = new Itinerario();
		itin.setId("13457");
		return id;

		}
}
