package mini;
/**
*Class Aviao que herda variaveis da class Veiculo
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class Aviao extends Veiculo{
	private String tipo;
	private String rotaaerea;
	
	public Aviao() {
		
	}
	/*
	 	*Gets e sets das variaveis da class Aviao 
	 */
	public String getTipo() {
		return tipo;
	} 
	public void setTipo(String tipo) {
		this.tipo=tipo;
	}
	
	
	public String getRotaaerea() {
		return rotaaerea;
	}
	public void setRotaaerea(String rotaaerea) {
		this.rotaaerea=rotaaerea;
	}
}

