package mini;

/**
*Class Veiculo é pai para outras classes sendo abstrata, deixando criado as variaveis desse
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public abstract class Veiculo{
	
	protected String marca;
	protected int ano_fab;
	protected int idveic;
	protected int assentos;
	protected int passageiros;
	
	public Veiculo() {
		
	}
	/*
	 	*Gets e sets das variaveis de um veiculo 
	 */
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca=marca;
	}
	
	
	
	public int getAno() {
		return ano_fab;
	}
	public void setAno(int ano_fab) {
		this.ano_fab=ano_fab;
	}
	

	public int getIdveic() {
		return idveic;
	}
	public void setIdveic(int idveic) {
		this.idveic=idveic;
	}
	

	public int getAssentos() {
		return assentos;
	}
	public void setAssentos(int assentos) {
		this.assentos=assentos;
	}
	
	
	
	public int getPassageiros() {
		return passageiros;
	}
	public void setPassageiros(int passageiros) {
		this.passageiros=passageiros;
	}
	

}
