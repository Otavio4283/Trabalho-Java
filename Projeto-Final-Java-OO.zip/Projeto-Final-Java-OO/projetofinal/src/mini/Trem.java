package mini;
/**
*Class Trem que herda variaveis da class Veiculo
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class Trem extends Veiculo{
	private String estacoes;
	private int vagoes;
	
	public Trem() {
		
	}
	/*
	 	*Gets e sets da classe Trem 
	 */
	public String getEstacoes() {
		return estacoes;
	}
	public void setEstacoes(String estacoes) {
		this.estacoes=estacoes;
	}
	
	
	public int getVagoes() {
		return vagoes;
	}
	public void setVagoes(int vagoes) {
		this.vagoes=vagoes;
	}
}