package mini;
/**
*Class Passagem que cria as variaveis dessa e da valor a elas
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class Passagem {
	String nome;
	int cpf;
	int itinerario;
	int clienteid;
	
	public Passagem() {
		
	}
	/*
	 	*Gets e sets das variaveis da classe Passagem 
	 */
	public int getItinerario() {
		return itinerario;
	}
	public void setItinerario(int itinerario) {
		this.itinerario=itinerario;
	}
	
	
	public int getClienteid() {
		return clienteid;
	}
	public void setClienteid(int clienteid) {
		this.clienteid=clienteid;
	}

	
	
	public int getCpf() {
		return cpf;
	}
	public void setCpf(int cpf) {
		this.cpf=cpf;
	}

	
	
	public int getNome() {
		return itinerario;
	}
	public void setNome(String nome) {
		this.nome=nome;
	}
}
