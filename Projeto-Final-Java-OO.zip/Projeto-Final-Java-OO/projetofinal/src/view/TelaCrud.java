package view;
import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.*;
import java.awt.event.*;

import mini.Itinerario;
/**
*Class TelaCrud, serva para definir qual dado deseja ser inserido, modificado ou excluido 
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class TelaCrud extends JFrame{
	public TelaCrud() {
		//Definições dos elementos presentes na classe
		JFrame frame = new JFrame("Crud");
		Color corDeFundo = new Color(118, 87, 182);
		Font fonte3 = new Font("Arial",Font.BOLD,8);
		Font fonte2 = new Font("Arial", Font.BOLD,18);
		JButton voltar3 = new JButton("Voltar");
		JLabel itin = new JLabel("Itinerários");
		JLabel veic = new JLabel("Veiculos");
		JLabel pass = new JLabel("Passagem");
		JButton criarItin = new JButton("Criar");
		JButton criarVeic = new JButton("Criar");
		JButton criarPass = new JButton("Criar");
		JButton editarItin = new JButton("Editar/Excluir");
		JButton editarVeic = new JButton("Editar/Excluir");
		JButton	editarPass = new JButton("Editar/Excluir");
		
		
		
		
		
		
        //Definição do botão que retorna para a tela inicial
        voltar3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	TelaInicial tela1 = new TelaInicial();
                tela1.setVisible(true);
                frame.dispose(); 
            }
        });
		
        //Definição do botão redireciona para o cadstro de itinerario
        criarItin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	CrudItinerario itin = new CrudItinerario();
                itin.setVisible(true);
                frame.dispose(); 
     	
            }
        });
        
        
        //Definição do botão que redireciona para a seleção do tipo de veiculo que será cadastrado(não necessário)
        criarVeic.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	SelVeic veiculo = new SelVeic();
                veiculo.setVisible(true);
                frame.dispose(); 
     	
            }
        });
        
        
        
        //Definição do botão que redireciona para o cadastro da passagem(não necessário)
        criarPass.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	CrudPassagem pass = new CrudPassagem();
                pass.setVisible(true);
                frame.dispose(); 
     	
            }
        });
		
        
        
        //Definição do botão que redireciona para a edição de itinerario
        editarItin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	EdicaoItin itin = new EdicaoItin();
                itin.setVisible(true);
                frame.dispose(); 
     	
            }
        });
        
        
        //Definição do botão que redireciona para a edição do veiculo(não necessário)
        editarVeic.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	SelVeic veiculo = new SelVeic();
                veiculo.setVisible(true);
                frame.dispose(); 
     	
            }
        });
        
        
        
        //Definição do botão que redireciona para a edição da passagem(não necessário)
        editarPass.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	CrudPassagem pass = new CrudPassagem();
                pass.setVisible(true);
                frame.dispose(); 
     	
            }
        });
        
        
        
        //Tamanho e posição dos elementos da classe
        itin.setBounds(38, 12, 100, 20);
		itin.setFont(fonte2);
		veic.setBounds(287, 12, 100, 20);
		veic.setFont(fonte2);
		pass.setBounds(536, 12, 100, 20);
		pass.setFont(fonte2);
		criarPass.setFont(fonte3);
        criarPass.setBounds(536, 70, 100, 20);
        criarVeic.setFont(fonte3);
        criarVeic.setBounds(287, 70, 100, 20);
        criarItin.setFont(fonte3);
        criarItin.setBounds(38, 70, 100, 20);
        editarItin.setFont(fonte3);
        editarItin.setBounds(38,128,100,15);
        editarVeic.setFont(fonte3);
        editarVeic.setBounds(287,128,100,15);
        editarPass.setFont(fonte3);
        editarPass.setBounds(536,128,100,15);
        voltar3.setFont(fonte3);
        voltar3.setBounds(9,450,100,15);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize(666, 555);
    	frame.getContentPane().setBackground(corDeFundo);
    	frame.setLayout(null);
    	
    	
    	
    	frame.add(criarItin);
    	frame.add(criarVeic);
    	frame.add(criarPass);
    	frame.add(itin);
    	frame.add(veic);
    	frame.add(pass);
    	frame.add(editarItin);
    	frame.add(editarVeic);
    	frame.add(editarPass);
    	frame.add(voltar3);
    	frame.setVisible(true);
	}
}