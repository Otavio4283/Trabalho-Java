package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import banco.Banco;
import mini.Itinerario;
/**
*Class SelVeic seleciona o tipo de veiculo que será cadastrado
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class SelVeic extends JFrame{
	public SelVeic() {
		//Definição dos elementos da classe
		JFrame frame = new JFrame("SelVeic");
		Color corDeFundo = new Color(118, 87, 182);
		Font fonte1 = new Font("Arial", Font.BOLD,48);
		Font fonte2 = new Font("Arial", Font.BOLD,12);
		Font fonte3 = new Font("Arial", Font.BOLD,8);
		JLabel qual = new JLabel("Qual o tipo de veiculo");
		JButton onibus = new JButton("Ônibus");
		JButton aviao = new JButton("Avião");
		JButton trem = new JButton("Trem");
		JButton voltar = new JButton("Voltar");
		
		//Botão que redireciona para o cadastro de onibus
		onibus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	CrudOnibus onibus = new CrudOnibus();
                onibus.setVisible(true);	
                frame.dispose(); 
            }
        });
		
		
		//Botão que redireciona para o cadastro de trem
		trem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	CrudTrem trem = new CrudTrem();
                trem.setVisible(true);
                dispose(); 
            }
        });
		
		
		//Botão que redireciona para o cadstro de avião
		aviao.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	CrudAviao aviao = new CrudAviao();
                aviao.setVisible(true);
                dispose(); 
            }
        });
		
		
		//Botão que retorna para a tela de crud
		voltar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	TelaCrud tela1 = new TelaCrud();
                tela1.setVisible(true);
                frame.dispose(); 
            }
        });
		
		//Tamanhos e posições dos elementos
		qual.setBounds(73, 167, 515, 58);
		qual.setFont(fonte1);
		onibus.setBounds(16,342,180,40);
		onibus.setFont(fonte2);
		aviao.setBounds(241, 342,180,40);
		aviao.setFont(fonte2);
		trem.setBounds(466, 342, 180, 40);
		trem.setFont(fonte2);
		voltar.setBounds(15, 460, 138, 20);
		voltar.setFont(fonte3);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize(666, 555);
    	frame.getContentPane().setBackground(corDeFundo);
    	
    	
    	frame.add(qual);
    	frame.add(aviao);
    	frame.add(onibus);
    	frame.add(trem);
    	frame.add(voltar);
    	frame.setLayout(null);
    	frame.setVisible(true);
		
		
	}
}
