package view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;


import mini.Itinerario;
import banco.Banco;
public class TelaLista extends JFrame{
	private JLabel idLabel;
    private JLabel origemLabel;
    private JLabel destinoLabel;
    private JLabel datasaidaLabel;
    private JLabel datachegadaLabel;
    private JLabel horariosaidaLabel;
    private JLabel horariochegadaLabel;
/**
	*Class Lista ela imprime os itinerarios que foram registrados
	*@author Otávio Henrique Moraes Brito
	*@since 2023
	*@version 1.1
**/
	public TelaLista() {
		//Definição dos elementos gerais da tela
		JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        Color corDeFundo = new Color(118, 87, 182);
		Font fonte3 = new Font("Arial", Font.BOLD,8);
		JButton voltar = new JButton("Voltar");
		ArrayList<Itinerario> itinerarios = Banco.getItinerario();

		   
		
		
		//Definiçao do botao que voltara para a tela inicial
		voltar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	TelaInicial tela1 = new TelaInicial();
                tela1.setVisible(true);
                frame.dispose(); 
            }
        });
		
		     
        //Define se a lista itinerario está vazio ou não. Caso tenha dados ira imprimi-los na tela.
        if (itinerarios.isEmpty()) {
        	JOptionPane.showMessageDialog(null, "Não existem itinerarios");
        	TelaInicial tela2 = new TelaInicial();
        	tela2.setVisible(true);
        	frame.dispose();
        } else {
            for (Itinerario itinerario : itinerarios) {
            	//definiçoes dos labels, que irão variar por isso são definidos nessa área
                JLabel idLabel = new JLabel("ID: " + itinerario.getId());
                JLabel origemLabel = new JLabel("Origem: " + itinerario.getOrigem());
                JLabel destinoLabel = new JLabel("Destino: " + itinerario.getDestino());
                JLabel datasaidaLabel = new JLabel("Data de Saída: " + itinerario.getDatasaida());
                JLabel datachegadaLabel = new JLabel("Data de Chegada: " + itinerario.getDatachegada());
                JLabel horariosaidaLabel = new JLabel("Horário de Saída: " + itinerario.getHorariosaida());
                JLabel horariochegadaLabel = new JLabel("Horário de Chegada: " + itinerario.getHorariochegada());             
 
                panel.add(idLabel);
                panel.add(origemLabel);
                panel.add(destinoLabel);
                panel.add(datasaidaLabel);
                panel.add(datachegadaLabel);
                panel.add(horariosaidaLabel);
                panel.add(horariochegadaLabel);
                voltar.setBounds(13, 458, 100, 20);
                panel.add(voltar);
                
            }
        }
 
		panel.setBounds(33, 55, 500, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize(666, 555);
    	frame.getContentPane().setBackground(corDeFundo);
    	frame.add(panel);
    	frame.setVisible(true);
    

	}
}
