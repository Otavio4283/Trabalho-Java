package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
*Class TelaInicial que mostra a primeira tela do trabalho
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class TelaInicial extends JFrame{
	
    public TelaInicial() {
    	//Definição dos elementos da tela
    	JFrame frame = new JFrame("Tela1");
    	JLabel label = new JLabel("Tribuss Viagens");
        Font fonte = new Font("Arial", Font.BOLD, 40);
        JButton botao1 = new JButton("Listar Itinerarios");
        JButton botao2 = new JButton("Pesquisar uma data de viagem:");
        JButton botao3 = new JButton("Administrador");
        Color corDeFundo = new Color(118, 87, 182);
        Font fonte1 = new Font("Arial", Font.BOLD,8);
        
        //Funcionalidade do botao que redireciona para a lista deitinerarios
        botao1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	TelaLista telalistas = new TelaLista();
                telalistas.setVisible(true);
                frame.dispose(); 
            }
        });
        
        
       //Funcionalidade do botao que redireciona para a pagina de pesquisa
        botao2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	TelaBusca telabusca = new TelaBusca();
                telabusca.setVisible(true);
                frame.dispose(); 
            }
        });
        
        
        //Funcionalidade do botao que redireciona para a pagina do administrador
        botao3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	TelaCrud telacrud = new TelaCrud();
                telacrud.setVisible(true);
                frame.dispose(); 
            }
        });
        
        
        //Set das caracteristicas dos elementos presentes
        label.setFont(fonte);
        label.setBounds(153,221,360,58);
        label.setVisible(true);
        botao1.setFont(fonte1);
        botao1.setBounds(9,13,100,15);
        botao2.setFont(fonte1);
        botao2.setBounds(413,13,200,15);
        botao3.setFont(fonte1);
        botao3.setBounds(223,13,100,15);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(666, 555);
        frame.getContentPane().setBackground(corDeFundo);
        frame.setLayout(null);
        
        
        
        frame.add(botao1);
        frame.add(botao2);
        frame.add(botao3);
        frame.add(label);
        frame.setVisible(true);
    }
    
    //Main que chama a class da tela inicial que leva a todas as outras
    public static void main(String[] args) {
        new TelaInicial();
    }
}