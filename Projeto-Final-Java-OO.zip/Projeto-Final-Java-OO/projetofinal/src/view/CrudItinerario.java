package view;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

import mini.Itinerario;
import banco.Banco;
/**
*Class CrudItinerario que cadastra os dados de um certo itinerario
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class CrudItinerario extends JFrame{
	public CrudItinerario() {
		//Definições dos elementos daclasse
		JFrame frame = new JFrame("CrudItin");
		Color corDeFundo = new Color(118, 87, 182);
		Font fonte3 = new Font("Arial", Font.BOLD,8);
		JLabel id = new JLabel("Id:");
		JTextField idCaixa = new JTextField();
		JLabel origem = new JLabel("Origem:");
		JTextField origemCaixa = new JTextField();
		JLabel destino = new JLabel ("Destino:");
		JTextField destinoCaixa = new JTextField();
		JLabel datasaida = new JLabel("Data de Saida(XX/XX/XXXX):");
		JTextField datasaidaCaixa = new JTextField();
		JLabel datachegada = new JLabel("Data de Chegada(XX/XX/XXXX):");
		JTextField datachegadaCaixa = new JTextField();
		JLabel horariosaida = new JLabel("Horario de Saida(XX:XX):");
		JTextField horariosaidaCaixa = new JTextField();
		JLabel horariochegada = new JLabel("Horario de Chegada(XX:XX):");
		JTextField horariochegadaCaixa = new JTextField();
		JButton voltar = new JButton("Voltar");
		JButton cadastrar = new JButton("Cadastrar");
		
		
		//Definição do botão que redireciona para a tela inicial
		voltar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	TelaCrud tela1 = new TelaCrud();
                tela1.setVisible(true);
                frame.dispose(); 
            }
        });
		
		
		//Definição do botão que cadastra os dados do itnerario
		cadastrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	//Cria um novo objeto
            	Itinerario itinerarioNovo = new Itinerario();
            	//Define as variaveis usadas apenas dentro desse actioPerfomed
            	String id = idCaixa.getText();
				String origem = origemCaixa.getText();
				String destino = destinoCaixa.getText();
				String dataSaida = datasaidaCaixa.getText();
				String dataChegada = datachegadaCaixa.getText();
				String horarioSaida = horariosaidaCaixa.getText();
				String horarioChegada = horariochegadaCaixa.getText();
				boolean resulId = (itinerarioNovo.checaId(id));
				boolean resulHora1 = (itinerarioNovo.checaHorario(horarioSaida));
				boolean resulHora2 = (itinerarioNovo.checaHorario(horarioChegada));
				boolean resulData1 = (itinerarioNovo.checaData(dataSaida));
				boolean resulData2 = (itinerarioNovo.checaData(dataChegada));
				//Checa se existe id repetido e se os horarios e dtas são validos
				if(resulId==false) {
					JOptionPane.showMessageDialog(null, "Id Invalido");
					CrudItinerario refazer = new CrudItinerario();
	                refazer.setVisible(true);
	                return;
				}
				if(resulHora1==false || resulHora2==false) {
					JOptionPane.showMessageDialog(null, "Horario Invalido");
					CrudItinerario refazer = new CrudItinerario();
	                refazer.setVisible(true);
	                return;
				}
				if(resulData1==false || resulData2==false) {
					JOptionPane.showMessageDialog(null, "Data Invalida");
					CrudItinerario refazer = new CrudItinerario();
	                refazer.setVisible(true);
	                return;
				}
				
				//seta as variaveis no objeto
            	itinerarioNovo.setId(id);
            	itinerarioNovo.setOrigem(origem);
            	itinerarioNovo.setDestino(destino);
            	itinerarioNovo.setDatasaida(dataSaida);
            	itinerarioNovo.setDatachegada(dataChegada);
            	itinerarioNovo.setHorariosaida(horarioSaida);
            	itinerarioNovo.setHorariochegada(horarioChegada);
                //Sobe esse objeto no banco de dados
            	Banco.getItinerario().add(itinerarioNovo);
            	
            	TelaInicial tela1 = new TelaInicial();
                tela1.setVisible(true);
            	frame.dispose(); 
                
                
            }
        });
		
		
		//Coloca os tamanhos e as posições dos elementos 
		id.setBounds(15, 14, 138, 20); ;
		idCaixa.setBounds(15, 47, 138, 20); 
		origem.setBounds(247, 14, 138, 20); 
		origemCaixa.setBounds(247, 47, 138, 20); 
		destino.setBounds(479, 14, 138, 20); 
		destinoCaixa.setBounds(479, 47, 138, 20); 
		datasaida.setBounds(15, 142, 168, 20); 
		datasaidaCaixa.setBounds(15, 175, 138, 20); 
		datachegada.setBounds(247, 142, 188, 20); 
		datachegadaCaixa.setBounds(247, 175, 138, 20); 
		horariosaida.setBounds(15, 286, 158, 20); 
		horariosaidaCaixa.setBounds(15, 319, 138, 20);  
		horariochegada.setBounds(247, 286, 168, 20); 
		horariochegadaCaixa.setBounds(247, 319, 138, 20); 
		voltar.setBounds(15, 460, 138, 20);
		voltar.setFont(fonte3);
		cadastrar.setBounds(479, 460, 138, 20);
		cadastrar.setFont(fonte3);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize(666, 555);
    	frame.getContentPane().setBackground(corDeFundo);
    	
    	
    	
    	frame.add(id);
    	frame.add(idCaixa);
    	frame.add(origem);
    	frame.add(origemCaixa);
    	frame.add(destino);
    	frame.add(destinoCaixa);
    	frame.add(datasaida);
    	frame.add(datasaidaCaixa);
    	frame.add(datachegada);
    	frame.add(datachegadaCaixa);
    	frame.add(horariosaida);
    	frame.add(horariosaidaCaixa);
    	frame.add(horariochegada);
    	frame.add(horariochegadaCaixa);
    	frame.add(cadastrar);
    	frame.add(voltar);
    	frame.setLayout(null);
    	frame.setVisible(true);
		
		
	}
}
