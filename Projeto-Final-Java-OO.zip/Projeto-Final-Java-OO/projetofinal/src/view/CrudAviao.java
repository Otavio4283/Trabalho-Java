package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import banco.Banco;
import mini.Veiculo;
import mini.Onibus;
/**
*Class CrudAviao que cadastra os veiculos do tipo aviao
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class CrudAviao extends JFrame{
	public CrudAviao() {
		//Definição dos elementos da classe
		JFrame frame = new JFrame("CrudAviao");
		Color corDeFundo = new Color(118, 87, 182);
		Font fonte3 = new Font("Arial", Font.BOLD,8);
		JLabel idveic = new JLabel("Id do Veiculo:");
		JTextField idveicCaixa = new JTextField();
		JLabel anofab = new JLabel("Ano de Fabricação:");
		JTextField anofabCaixa = new JTextField();
		JLabel marca = new JLabel ("Marca:");
		JTextField marcaCaixa = new JTextField();
		JLabel assentos = new JLabel("Assentos:");
		JTextField assentosCaixa = new JTextField();
		JLabel passageiros = new JLabel("Passageiros:");
		JTextField passageirosCaixa = new JTextField();
		JButton voltar = new JButton("Voltar");
		JButton cadastrar = new JButton("Cadastrar");
		
		//Definição do botão que redireciona para a tela inicia
		voltar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	TelaCrud tela1 = new TelaCrud();
                tela1.setVisible(true);
                frame.dispose(); 
            }
        });
		
		
		//Definição do cadastro de veiculos(não utilizado ou finalizado)
		cadastrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	Onibus veiculoNovo = new Onibus();
           
            	
            	int idveic = (Integer.parseInt(idveicCaixa.getText()));
				int anofab = (Integer.parseInt(anofabCaixa.getText()));
				String marca = marcaCaixa.getText();
				int assentos = (Integer.parseInt(assentosCaixa.getText()));
				int passageiros = (Integer.parseInt(passageirosCaixa.getText()));
				
            	veiculoNovo.setIdveic(idveic);
            	veiculoNovo.setAno(anofab);
            	veiculoNovo.setMarca(marca);
            	veiculoNovo.setAssentos(assentos);
            	veiculoNovo.setPassageiros(passageiros);
            	
                
            	Banco.getVeiculo().add(veiculoNovo);
            	
            	TelaInicial tela1 = new TelaInicial();
                tela1.setVisible(true);
            	frame.dispose(); 
                
                
            }
        });
		

		//Definicao a posição e o tamanho dos elementos
		voltar.setBounds(15, 460, 138, 20);
		voltar.setFont(fonte3);
		cadastrar.setBounds(479, 460, 138, 20);
		cadastrar.setFont(fonte3);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize(666, 555);
    	frame.getContentPane().setBackground(corDeFundo);
    	
    	
    	
       	frame.add(cadastrar);
    	frame.add(voltar);
    	frame.setLayout(null);
    	frame.setVisible(true);
		
		
	}
}