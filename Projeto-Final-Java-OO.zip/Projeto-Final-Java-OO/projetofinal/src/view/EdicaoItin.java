package view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

import mini.Itinerario;
import banco.Banco;
/**
*Class EdicaoItin edita os dados de um itinerario se existirem 
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class EdicaoItin extends JFrame{
		//Definição da varivel que identifica o id que foi escolhido
		private String idSelecionado;
	public EdicaoItin() {
		//Definição dos elementos da classe
		JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        JTextField idCaixa = new JTextField();
        Color corDeFundo = new Color(118, 87, 182);
		Font fonte3 = new Font("Arial", Font.BOLD,8);
		JButton excluir = new JButton("Excluir");
		JButton editar = new JButton("Editar");
		JButton voltar = new JButton("Voltar");
		ArrayList<Itinerario> itinerarios = Banco.getItinerario();
			
		
		
		
		
		//Definição da remoção de itinerarios. Identifica o id digitado. E o retira do banco de dados usando uma nova array list
		excluir.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String id = idCaixa.getText();
		        setIdSelecionado(id);
		        
		        List<Itinerario> itinerariosRemover = new ArrayList<>();
		        for (Itinerario itinerario : itinerarios) {
		            if (id.equals(itinerario.getId())) {
		                itinerariosRemover.add(itinerario);
		                Banco.getItinerario().remove(getIdSelecionado());
		            }
		        }
		        
		        itinerarios.removeAll(itinerariosRemover);
		        
		        TelaInicial tela1 = new TelaInicial();
		        tela1.setVisible(true);
		        frame.dispose(); 
		    }
		});


		
		
		//Definição da edição de itinerarios. Remove o itinerario e redireciona para o recadastrar o itinerario
		editar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	String id = idCaixa.getText();
		        setIdSelecionado(id);
		        
		        List<Itinerario> itinerariosRemover = new ArrayList<>();
		        for (Itinerario itinerario : itinerarios) {
		            if (id.equals(itinerario.getId())) {
		                itinerariosRemover.add(itinerario);
		                Banco.getItinerario().remove(getIdSelecionado());
		            }
		        }
		        
		        itinerarios.removeAll(itinerariosRemover);
		        
		        CrudItinerario tela1 = new CrudItinerario();
		        tela1.setVisible(true);
		        frame.dispose();
            }
        });
		
		
		//Botão que volta para a tela de crud
		voltar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	TelaCrud tela1 = new TelaCrud();
                tela1.setVisible(true);
                frame.dispose(); 
            }
        });
		
		
		
    
      

   
        
        //Identifica se existem itinerarios, caso não retorna para a tela de crud. Caso existam vai levar para uma tela com as listas dos ids de itinerarios existentes
        if (itinerarios.isEmpty()) {
        	JOptionPane.showMessageDialog(null, "Não existem itinerarios");
        	TelaCrud tela1 = new TelaCrud();
        	tela1.setVisible(true);
        	frame.dispose();
        } else {
            for (Itinerario itinerario : itinerarios) {
                JLabel idLabel = new JLabel("ID: " + itinerario.getId());     
    
                panel.add(idLabel);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(666, 555);
            	
                panel.setBounds(33, 55, 500, 400);
                frame.getContentPane().setBackground(corDeFundo);
                frame.add(voltar);
                frame.add(idCaixa);
                frame.add(editar);
                frame.add(excluir);
            	frame.add(panel);
                frame.setVisible(true);
            }
        }
        
        
        //Tamanho e posição dos elementos
        idCaixa.setBounds(264,397, 138, 20); 
		excluir.setBounds(264, 460,138, 20);
		excluir.setFont(fonte3);
		editar.setBounds(479, 460,138 , 20);
		editar.setFont(fonte3);
		voltar.setBounds(15, 460, 138, 20);
		voltar.setFont(fonte3);

	}
	
	
	
	
	
	public void setIdSelecionado(String id) {
		idSelecionado = id;
	}
	
	public String getIdSelecionado() {
		return idSelecionado;
	}
}
	