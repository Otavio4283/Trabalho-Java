package view;
import javax.swing.*;

import banco.Banco;
import mini.Itinerario;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
/**
*Class TelaBusca que busca se certo itinerario existe no banco de dados
*@author Otávio Henrique Moraes Brito
*@since 2023
*@version 1.1
**/
public class TelaBusca extends JFrame{
		//Variaveis usadas na classe
		private boolean encontrado = false;
	public TelaBusca() {
		//Elementos da classe em questão
		JTextField pesquisaBox = new JTextField();
		JButton pesquisa = new JButton("Pesquisar");
		JButton voltar2 = new JButton("Voltar");
		JPanel panel = new JPanel();
		Font fonte2 = new Font("Arial", Font.BOLD,8);
        JFrame frame = new JFrame("Tela Busca");
        Color corDeFundo = new Color(118, 87, 182);
        ArrayList<Itinerario> itinerarios = Banco.getItinerario();
        
        
        //Botão que realiza a pesquisa
        pesquisa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	//Cria uma variavel com o valor que foi digitado
            	String pesquisa = pesquisaBox.getText();
            	//Retorna para tela inicial caso não existam itinerarios 
            	if (itinerarios.isEmpty()) {
                 	JOptionPane.showMessageDialog(null, "Não existem itinerarios");
                 	TelaInicial tela1 = new TelaInicial();
                     tela1.setVisible(true);
                     frame.dispose(); 
                 } else {
                	 //analise todos os itinerarios o banco de dados. Se a data de saida de algum for igual ao digitado imprime na tela um aviso e os dados do itinerario. Caso o contrario avisa o usuario
                     for (Itinerario itinerario : itinerarios) {
                        if(pesquisa.equals(itinerario.getDatasaida())) {
                        	JFrame resultado = new JFrame();
                        	JLabel idLabel = new JLabel("ID: " + itinerario.getId());
                            JLabel origemLabel = new JLabel("Origem: " + itinerario.getOrigem());
                            JLabel destinoLabel = new JLabel("Destino: " + itinerario.getDestino());
                            JLabel datasaidaLabel = new JLabel("Data de Saída: " + itinerario.getDatasaida());
                            JLabel datachegadaLabel = new JLabel("Data de Chegada: " + itinerario.getDatachegada());
                            JLabel horariosaidaLabel = new JLabel("Horário de Saída: " + itinerario.getHorariosaida());
                            JLabel horariochegadaLabel = new JLabel("Horário de Chegada: " + itinerario.getHorariochegada());             
                            JLabel espaço = new JLabel ("\n");
                            
                            panel.add(idLabel);
                            panel.add(origemLabel);
                            panel.add(destinoLabel);
                            panel.add(datasaidaLabel);
                            panel.add(datachegadaLabel);
                            panel.add(horariosaidaLabel);
                            panel.add(horariochegadaLabel);
                            panel.add(espaço);
                            encontrado = true;
                            resultado.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            resultado.setSize(666, 555);
                        	
                            panel.setBounds(33, 55, 500, 400);
                            resultado.getContentPane().setBackground(corDeFundo);
                            resultado.add(voltar2);
                        	resultado.add(panel);
                            resultado.setVisible(true);
                            JOptionPane.showMessageDialog(null, "Itinerario Encontrado");
                        }
                     
                     }
                    
                 }
            	 if(encontrado!=true) {
            		 JOptionPane.showMessageDialog(null, "Nenhum itinerário para essa data de saída");
            	 }
            }
        });
        
        
        //Botão que voltara para a tela inicial 
        voltar2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	TelaInicial voltar2 = new TelaInicial();
                voltar2.setVisible(true);
                frame.dispose(); 
            }
        });
		
		//Tamanho e posição dos elementos da classe
        pesquisaBox.setBounds(15,14,500, 20);
        pesquisa.setBounds(528,14,97,20);
        voltar2.setFont(fonte2);
        voltar2.setBounds(14,458,100,15);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize(666, 555);
    	
    	
    	frame.getContentPane().setBackground(corDeFundo);
    	frame.setLayout(null);
    	frame.add(voltar2);
    	frame.add(pesquisa);
    	frame.add(pesquisaBox);
    	frame.add(panel);
    	frame.setVisible(true);
    	
	}
}
